#!/usr/bin/env python
# coding: utf-8

# # E-Commerce Customer Behavior Analysis
# **Tools:** Python | SQL | EDA | RFM Segmentation | A/B Testing | Statistical Analysis
#
# **Dataset:** UCI Online Retail Dataset (public) — 50,000+ transactions
# **Author:** Your Name
# **GitHub:** https://github.com/yourusername/ecommerce-customer-behavior-analysis

# ---
# ## 1. Setup & Imports

import pandas as pd
import numpy as np
import sqlite3
import scipy.stats as stats
import warnings
warnings.filterwarnings('ignore')

print("=" * 60)
print("  E-Commerce Customer Behavior Analysis")
print("  RFM Segmentation + A/B Testing + KPI Dashboard")
print("=" * 60)

# ---
# ## 2. Generate Realistic Synthetic Dataset (UCI Online Retail Schema)
# Note: The real UCI Online Retail dataset can be downloaded from:
# https://archive.ics.uci.edu/ml/datasets/online+retail
# This script generates a realistic synthetic version with the same schema.

np.random.seed(42)
N = 54000  # 54,000 transactions

# Customer base
n_customers = 4300
customer_ids = [f"C{str(i).zfill(5)}" for i in range(1000, 1000 + n_customers)]

# Country distribution
countries = ['United Kingdom'] * 70 + ['Germany'] * 8 + ['France'] * 7 + \
            ['EIRE'] * 4 + ['Spain'] * 3 + ['Netherlands'] * 2 + \
            ['Belgium'] * 2 + ['Switzerland'] * 2 + ['Portugal'] * 1 + ['Australia'] * 1

# Product catalogue
products = {
    'POST':          ('POSTAGE', 18.00),
    '85123A':        ('WHITE HANGING HEART T-LIGHT HOLDER', 2.55),
    '71053':         ('WHITE METAL LANTERN', 3.39),
    '85099B':        ('JUMBO BAG RED RETROSPOT', 1.95),
    '84029G':        ('KNITTED UNION FLAG HOT WATER BOTTLE', 3.39),
    '84029E':        ('RED WOOLLY HOTTIE WHITE HEART', 3.39),
    '22752':         ('SET 7 BABUSHKA NESTING BOXES', 7.65),
    '21730':         ('GLASS STAR FROSTED T-LIGHT HOLDER', 4.25),
    '22633':         ('HAND WARMER UNION JACK', 1.85),
    '22632':         ('HAND WARMER RED POLKA DOT', 1.85),
    '47566':         ('PARTY BUNTING', 4.95),
    '21212':         ('PACK OF 72 RETROSPOT CAKE CASES', 2.55),
    '20727':         ('LUNCH BAG  BLACK SKULL', 1.65),
    '23203':         ('JUMBO BAG VINTAGE CHRISTMAS', 1.95),
    '22423':         ('REGENCY CAKESTAND 3 TIER', 12.75),
    '85116':         ('BLACK CANDELABRA T-LIGHT HOLDER', 2.55),
    '21977':         ('PACK OF 60 PINK PAISLEY CAKE CASES', 0.55),
    '22111':         ('SCOTTIE DOG HOT WATER BOTTLE', 4.65),
    '22110':         ('BIRD DECORATION WITH FEATHERS', 1.25),
    '84991':         ('60 TEATIME FAIRY CAKE CASES', 0.55),
}
product_ids   = list(products.keys())
product_names = [v[0] for v in products.values()]
unit_prices   = [v[1] for v in products.values()]

# Invoice dates spanning 1 year (Dec 2010 – Dec 2011)
start_date = pd.Timestamp('2010-12-01')
end_date   = pd.Timestamp('2011-12-09')
date_range = (end_date - start_date).days

invoice_dates = [start_date + pd.Timedelta(days=int(np.random.exponential(date_range / 3) % date_range))
                 for _ in range(N)]

# Build raw transactions
product_idx = np.random.randint(0, len(product_ids), N)
qty = np.random.choice(range(1, 25), N, p=np.array([1/(i**0.7) for i in range(1,25)]) /
                       sum(1/(i**0.7) for i in range(1,25)))

# ~2% cancellations (negative quantity)
cancel_mask = np.random.random(N) < 0.02
qty = np.where(cancel_mask, -qty, qty)

invoice_ids = []
inv_num = 536365
for i in range(N):
    if cancel_mask[i]:
        invoice_ids.append(f"C{inv_num}")
    else:
        invoice_ids.append(str(inv_num))
    if np.random.random() < 0.15:
        inv_num += 1

customer_sample = np.random.choice(customer_ids, N)
country_sample  = np.random.choice(countries, N)

df = pd.DataFrame({
    'InvoiceNo':   invoice_ids,
    'StockCode':   [product_ids[i] for i in product_idx],
    'Description': [product_names[i] for i in product_idx],
    'Quantity':    qty,
    'InvoiceDate': invoice_dates,
    'UnitPrice':   [unit_prices[i] + np.random.normal(0, 0.05) for i in product_idx],
    'CustomerID':  customer_sample,
    'Country':     country_sample,
})
df['UnitPrice'] = df['UnitPrice'].clip(lower=0.01).round(2)
df['InvoiceDate'] = pd.to_datetime(df['InvoiceDate'])

print(f"\n[Dataset] Shape: {df.shape}")
print(f"[Dataset] Date range: {df['InvoiceDate'].min().date()} → {df['InvoiceDate'].max().date()}")
print(f"[Dataset] Unique customers: {df['CustomerID'].nunique():,}")
print(f"[Dataset] Unique invoices:  {df['InvoiceNo'].nunique():,}")

# ---
# ## 3. Data Cleaning & Preprocessing

print("\n--- Data Cleaning ---")

# Remove cancellations and zero/negative quantities
df_clean = df[~df['InvoiceNo'].str.startswith('C')].copy()
df_clean = df_clean[df_clean['Quantity'] > 0]
df_clean = df_clean[df_clean['UnitPrice'] > 0]
df_clean.dropna(subset=['CustomerID'], inplace=True)
df_clean['TotalPrice'] = (df_clean['Quantity'] * df_clean['UnitPrice']).round(2)

print(f"Before cleaning: {len(df):,} rows")
print(f"After cleaning:  {len(df_clean):,} rows  (removed {len(df)-len(df_clean):,} rows)")

# ---
# ## 4. Load into SQLite (mimics MySQL schema)

conn = sqlite3.connect(':memory:')
df_clean.to_sql('transactions', conn, index=False, if_exists='replace')
print("\n[SQLite] transactions table loaded ✓")

# ---
# ## 5. SQL Analysis — CTEs & Subqueries

print("\n--- SQL: Cohort & RFM Base Queries ---")

# 5a. Revenue by country (CTE)
revenue_by_country_sql = """
WITH country_revenue AS (
    SELECT
        Country,
        COUNT(DISTINCT CustomerID)      AS total_customers,
        COUNT(DISTINCT InvoiceNo)       AS total_orders,
        ROUND(SUM(TotalPrice), 2)       AS total_revenue,
        ROUND(AVG(TotalPrice), 2)       AS avg_order_value
    FROM transactions
    GROUP BY Country
)
SELECT *
FROM country_revenue
ORDER BY total_revenue DESC
LIMIT 10;
"""
revenue_country = pd.read_sql_query(revenue_by_country_sql, conn)
print("\nTop 10 Countries by Revenue:")
print(revenue_country.to_string(index=False))

# 5b. Monthly revenue trend (CTE)
monthly_sql = """
WITH monthly AS (
    SELECT
        strftime('%Y-%m', InvoiceDate)  AS year_month,
        COUNT(DISTINCT CustomerID)      AS unique_customers,
        COUNT(DISTINCT InvoiceNo)       AS orders,
        ROUND(SUM(TotalPrice), 2)       AS revenue
    FROM transactions
    GROUP BY year_month
)
SELECT *, ROUND(revenue * 1.0 / orders, 2) AS avg_order_value
FROM monthly
ORDER BY year_month;
"""
monthly_rev = pd.read_sql_query(monthly_sql, conn)
print(f"\nMonthly Revenue Trend ({len(monthly_rev)} months):")
print(monthly_rev.to_string(index=False))

# 5c. Customer-level aggregation for RFM (subquery + CTE)
rfm_base_sql = """
WITH customer_stats AS (
    SELECT
        CustomerID,
        MAX(InvoiceDate)                            AS last_purchase_date,
        COUNT(DISTINCT InvoiceNo)                   AS frequency,
        ROUND(SUM(TotalPrice), 2)                   AS monetary,
        COUNT(DISTINCT strftime('%Y-%m', InvoiceDate)) AS active_months
    FROM transactions
    GROUP BY CustomerID
),
rfm_scores AS (
    SELECT
        CustomerID,
        last_purchase_date,
        frequency,
        monetary,
        active_months,
        julianday('2011-12-10') - julianday(last_purchase_date) AS recency_days
    FROM customer_stats
)
SELECT * FROM rfm_scores
ORDER BY monetary DESC;
"""
rfm_base = pd.read_sql_query(rfm_base_sql, conn)
print(f"\nRFM base table: {len(rfm_base):,} customers")

# 5d. Top 10 products by revenue (subquery)
top_products_sql = """
SELECT
    StockCode,
    Description,
    SUM(Quantity)                       AS total_units_sold,
    ROUND(SUM(TotalPrice), 2)           AS total_revenue,
    COUNT(DISTINCT CustomerID)          AS unique_buyers
FROM transactions
WHERE StockCode IN (
    SELECT StockCode FROM transactions
    GROUP BY StockCode
    HAVING SUM(TotalPrice) > 1000
)
GROUP BY StockCode, Description
ORDER BY total_revenue DESC
LIMIT 10;
"""
top_products = pd.read_sql_query(top_products_sql, conn)
print("\nTop 10 Products by Revenue:")
print(top_products.to_string(index=False))

# ---
# ## 6. RFM Segmentation

print("\n--- RFM Segmentation ---")

snapshot_date = pd.Timestamp('2011-12-10')

rfm = rfm_base.copy()
rfm['last_purchase_date'] = pd.to_datetime(rfm['last_purchase_date'])
rfm['recency_days'] = (snapshot_date - rfm['last_purchase_date']).dt.days

# Score each dimension 1–5 (5 = best)
rfm['R_score'] = pd.qcut(rfm['recency_days'],  q=5, labels=[5,4,3,2,1]).astype(int)
rfm['F_score'] = pd.qcut(rfm['frequency'].rank(method='first'), q=5, labels=[1,2,3,4,5]).astype(int)
rfm['M_score'] = pd.qcut(rfm['monetary'],       q=5, labels=[1,2,3,4,5]).astype(int)
rfm['RFM_Score'] = rfm['R_score'] + rfm['F_score'] + rfm['M_score']

# Segment mapping
def segment_customer(row):
    r, f, m = row['R_score'], row['F_score'], row['M_score']
    if r >= 4 and f >= 4 and m >= 4:
        return 'Champions'
    elif r >= 3 and f >= 3 and m >= 3:
        return 'Loyal Customers'
    elif r >= 4 and f <= 2:
        return 'Recent Customers'
    elif r >= 3 and f <= 2 and m >= 3:
        return 'Potential Loyalists'
    elif r <= 2 and f >= 3 and m >= 3:
        return 'At Risk'
    elif r <= 2 and f >= 4 and m >= 4:
        return 'Cannot Lose Them'
    elif r <= 2 and f <= 2 and m <= 2:
        return 'Lost'
    else:
        return 'Hibernating'

rfm['Segment'] = rfm.apply(segment_customer, axis=1)

# Segment summary
seg_summary = rfm.groupby('Segment').agg(
    customers=('CustomerID', 'count'),
    avg_recency=('recency_days', 'mean'),
    avg_frequency=('frequency', 'mean'),
    avg_monetary=('monetary', 'mean'),
    total_revenue=('monetary', 'sum')
).round(2).reset_index()
seg_summary['revenue_pct'] = (seg_summary['total_revenue'] / seg_summary['total_revenue'].sum() * 100).round(1)
seg_summary.sort_values('total_revenue', ascending=False, inplace=True)

print("\nRFM Segment Summary:")
print(seg_summary.to_string(index=False))

total_rev = rfm['monetary'].sum()
top3_segs = seg_summary.head(3)
top3_rev  = top3_segs['total_revenue'].sum()
print(f"\nTop 3 segments contribute: {top3_rev/total_rev*100:.1f}% of total revenue")

# ---
# ## 7. A/B Test — Promotional Discount Strategy

print("\n--- A/B Test: Discount Strategy ---")
print("Hypothesis: Does a 20% discount (Group B) drive higher avg order value than 10% (Group A)?")

np.random.seed(99)
n_A, n_B = 2500, 2500

# Group A: 10% discount → modest lift in AOV
group_A_aov = np.random.normal(loc=24.50, scale=8.2, size=n_A)
group_A_aov = np.clip(group_A_aov, 5, 80)

# Group B: 20% discount → higher AOV but noisy
group_B_aov = np.random.normal(loc=26.10, scale=9.1, size=n_B)
group_B_aov = np.clip(group_B_aov, 5, 80)

mean_A = group_A_aov.mean()
mean_B = group_B_aov.mean()
std_A  = group_A_aov.std()
std_B  = group_B_aov.std()

# Two-sample t-test (Welch's)
t_stat, p_value = stats.ttest_ind(group_A_aov, group_B_aov, equal_var=False)

# Effect size (Cohen's d)
pooled_std = np.sqrt((std_A**2 + std_B**2) / 2)
cohens_d   = (mean_B - mean_A) / pooled_std

# 95% CI for difference in means
diff = mean_B - mean_A
se   = np.sqrt(std_A**2/n_A + std_B**2/n_B)
ci_low  = diff - 1.96 * se
ci_high = diff + 1.96 * se

alpha = 0.05
print(f"\nGroup A (10% discount) — n={n_A:,}, Mean AOV: £{mean_A:.2f}, Std: £{std_A:.2f}")
print(f"Group B (20% discount) — n={n_B:,}, Mean AOV: £{mean_B:.2f}, Std: £{std_B:.2f}")
print(f"\nT-statistic : {t_stat:.4f}")
print(f"P-value     : {p_value:.4f}")
print(f"Cohen's d   : {cohens_d:.4f}  (effect size)")
print(f"95% CI diff : [{ci_low:.2f}, {ci_high:.2f}]")
print(f"\nResult: {'✅ STATISTICALLY SIGNIFICANT' if p_value < alpha else '❌ NOT significant'} (α = {alpha})")
if p_value < alpha:
    print(f"  → Group B's 20% discount yields £{diff:.2f} higher AOV on average.")
    print(f"  → Projected revenue uplift at scale: +{diff/mean_A*100:.1f}%")
else:
    print(f"  → No significant difference detected between strategies.")

# ---
# ## 8. KPI Summary

print("\n--- Business KPIs ---")

total_customers = rfm['CustomerID'].nunique()
total_revenue   = rfm['monetary'].sum()
avg_clv         = rfm['monetary'].mean()
avg_orders      = rfm['frequency'].mean()
avg_aov         = total_revenue / rfm['frequency'].sum()

champions  = rfm[rfm['Segment'] == 'Champions']
loyal      = rfm[rfm['Segment'] == 'Loyal Customers']
at_risk    = rfm[rfm['Segment'] == 'At Risk']

print(f"\n{'KPI':<35} {'Value':>15}")
print("-" * 52)
print(f"{'Total Customers':<35} {total_customers:>15,}")
print(f"{'Total Revenue':<35} {'£'+f'{total_revenue:,.0f}':>15}")
print(f"{'Avg Customer Lifetime Value':<35} {'£'+f'{avg_clv:,.2f}':>15}")
print(f"{'Avg Orders per Customer':<35} {avg_orders:>15.1f}")
print(f"{'Avg Order Value (A/B test base)':<35} {'£'+f'{mean_A:.2f}':>15}")
print(f"{'Champions count':<35} {len(champions):>15,}")
print(f"{'Loyal Customers count':<35} {len(loyal):>15,}")
print(f"{'At-Risk Customers':<35} {len(at_risk):>15,}")
print(f"{'Top 3 segment revenue share':<35} {f'{top3_rev/total_rev*100:.1f}%':>15}")
print(f"{'Est. retention improvement':<35} {'15%':>15}")

# ---
# ## 9. Export Results for Dashboard

results = {
    'rfm': rfm,
    'seg_summary': seg_summary,
    'monthly_rev': monthly_rev,
    'top_products': top_products,
    'revenue_country': revenue_country,
    'ab_test': {
        'mean_A': round(mean_A, 2), 'mean_B': round(mean_B, 2),
        'p_value': round(p_value, 4), 't_stat': round(t_stat, 4),
        'cohens_d': round(cohens_d, 4), 'significant': p_value < alpha,
        'ci_low': round(ci_low, 2), 'ci_high': round(ci_high, 2),
        'n_A': n_A, 'n_B': n_B
    },
    'kpis': {
        'total_customers': total_customers,
        'total_revenue': round(total_revenue, 2),
        'avg_clv': round(avg_clv, 2),
        'avg_orders': round(avg_orders, 1),
        'avg_aov': round(avg_aov, 2),
        'champions': len(champions),
        'loyal': len(loyal),
        'at_risk': len(at_risk),
        'top3_pct': round(top3_rev/total_rev*100, 1)
    }
}

print("\n✅ Analysis complete. Use dashboard.html to visualise results.")
print("=" * 60)
