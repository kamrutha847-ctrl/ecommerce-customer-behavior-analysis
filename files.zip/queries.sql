-- =============================================================================
-- E-Commerce Customer Behavior Analysis
-- SQL Queries: CTEs, Subqueries, Cohort Analysis, RFM Base
-- Database: MySQL 8.0 compatible (also runs in SQLite with minor adjustments)
-- Author: Your Name
-- =============================================================================

-- =============================================================================
-- SCHEMA
-- =============================================================================

CREATE TABLE IF NOT EXISTS transactions (
    InvoiceNo   VARCHAR(20),
    StockCode   VARCHAR(20),
    Description VARCHAR(255),
    Quantity    INT,
    InvoiceDate DATETIME,
    UnitPrice   DECIMAL(10,2),
    CustomerID  VARCHAR(20),
    Country     VARCHAR(100),
    TotalPrice  DECIMAL(10,2)
);

-- =============================================================================
-- SECTION 1: EXPLORATORY DATA ANALYSIS
-- =============================================================================

-- 1.1 Dataset Overview
SELECT
    COUNT(*)                            AS total_rows,
    COUNT(DISTINCT CustomerID)          AS unique_customers,
    COUNT(DISTINCT InvoiceNo)           AS unique_invoices,
    COUNT(DISTINCT StockCode)           AS unique_products,
    COUNT(DISTINCT Country)             AS unique_countries,
    MIN(InvoiceDate)                    AS earliest_date,
    MAX(InvoiceDate)                    AS latest_date,
    ROUND(SUM(TotalPrice), 2)           AS total_revenue
FROM transactions
WHERE Quantity > 0 AND UnitPrice > 0
  AND InvoiceNo NOT LIKE 'C%';


-- 1.2 Monthly Revenue Trend (CTE)
WITH monthly_stats AS (
    SELECT
        DATE_FORMAT(InvoiceDate, '%Y-%m')       AS year_month,
        COUNT(DISTINCT CustomerID)              AS unique_customers,
        COUNT(DISTINCT InvoiceNo)               AS total_orders,
        ROUND(SUM(TotalPrice), 2)               AS revenue,
        ROUND(AVG(TotalPrice), 2)               AS avg_order_value
    FROM transactions
    WHERE Quantity > 0 AND UnitPrice > 0
      AND InvoiceNo NOT LIKE 'C%'
    GROUP BY year_month
)
SELECT
    year_month,
    unique_customers,
    total_orders,
    revenue,
    avg_order_value,
    ROUND(
        (revenue - LAG(revenue) OVER (ORDER BY year_month)) /
        LAG(revenue) OVER (ORDER BY year_month) * 100
    , 2)                                        AS mom_revenue_growth_pct
FROM monthly_stats
ORDER BY year_month;


-- 1.3 Revenue by Country (CTE)
WITH country_revenue AS (
    SELECT
        Country,
        COUNT(DISTINCT CustomerID)              AS total_customers,
        COUNT(DISTINCT InvoiceNo)               AS total_orders,
        ROUND(SUM(TotalPrice), 2)               AS total_revenue,
        ROUND(AVG(TotalPrice), 2)               AS avg_order_value,
        ROUND(SUM(TotalPrice) * 100.0 /
              SUM(SUM(TotalPrice)) OVER (), 2)  AS revenue_pct
    FROM transactions
    WHERE Quantity > 0 AND UnitPrice > 0
      AND InvoiceNo NOT LIKE 'C%'
    GROUP BY Country
)
SELECT *
FROM country_revenue
ORDER BY total_revenue DESC
LIMIT 10;


-- 1.4 Top 20 Products by Revenue (Subquery filter)
SELECT
    StockCode,
    Description,
    SUM(Quantity)                               AS total_units_sold,
    ROUND(SUM(TotalPrice), 2)                   AS total_revenue,
    COUNT(DISTINCT CustomerID)                  AS unique_buyers,
    ROUND(AVG(UnitPrice), 2)                    AS avg_unit_price
FROM transactions
WHERE StockCode IN (
    SELECT StockCode
    FROM transactions
    WHERE Quantity > 0 AND UnitPrice > 0
      AND InvoiceNo NOT LIKE 'C%'
    GROUP BY StockCode
    HAVING SUM(TotalPrice) > 500
)
AND InvoiceNo NOT LIKE 'C%'
AND Quantity > 0
GROUP BY StockCode, Description
ORDER BY total_revenue DESC
LIMIT 20;


-- =============================================================================
-- SECTION 2: RFM (RECENCY, FREQUENCY, MONETARY) ANALYSIS
-- =============================================================================

-- 2.1 Customer-Level RFM Base Table (Multi-CTE)
WITH snapshot AS (
    -- Define analysis snapshot date (day after last transaction)
    SELECT DATE('2011-12-10') AS snapshot_date
),
customer_stats AS (
    SELECT
        t.CustomerID,
        MAX(t.InvoiceDate)                              AS last_purchase_date,
        COUNT(DISTINCT t.InvoiceNo)                     AS frequency,
        ROUND(SUM(t.TotalPrice), 2)                     AS monetary,
        COUNT(DISTINCT DATE_FORMAT(t.InvoiceDate,'%Y-%m')) AS active_months,
        MIN(t.InvoiceDate)                              AS first_purchase_date
    FROM transactions t
    WHERE t.Quantity > 0
      AND t.UnitPrice > 0
      AND t.InvoiceNo NOT LIKE 'C%'
    GROUP BY t.CustomerID
),
rfm_raw AS (
    SELECT
        cs.CustomerID,
        cs.last_purchase_date,
        cs.first_purchase_date,
        cs.frequency,
        cs.monetary,
        cs.active_months,
        DATEDIFF(s.snapshot_date, cs.last_purchase_date)   AS recency_days,
        ROUND(cs.monetary / cs.frequency, 2)               AS avg_order_value,
        DATEDIFF(cs.last_purchase_date, cs.first_purchase_date) AS customer_lifespan_days
    FROM customer_stats cs
    CROSS JOIN snapshot s
)
SELECT * FROM rfm_raw
ORDER BY monetary DESC;


-- 2.2 RFM Scoring with NTILE (MySQL 8.0+)
WITH snapshot AS (SELECT DATE('2011-12-10') AS snapshot_date),
customer_stats AS (
    SELECT
        CustomerID,
        MAX(InvoiceDate)            AS last_purchase_date,
        COUNT(DISTINCT InvoiceNo)   AS frequency,
        ROUND(SUM(TotalPrice), 2)   AS monetary
    FROM transactions
    WHERE Quantity > 0 AND UnitPrice > 0
      AND InvoiceNo NOT LIKE 'C%'
    GROUP BY CustomerID
),
rfm_raw AS (
    SELECT
        cs.*,
        DATEDIFF(s.snapshot_date, cs.last_purchase_date) AS recency_days
    FROM customer_stats cs CROSS JOIN snapshot s
),
rfm_scored AS (
    SELECT
        *,
        -- R: lower recency_days = more recent = higher score
        NTILE(5) OVER (ORDER BY recency_days DESC)  AS R_score,
        -- F: higher frequency = higher score
        NTILE(5) OVER (ORDER BY frequency ASC)      AS F_score,
        -- M: higher monetary = higher score
        NTILE(5) OVER (ORDER BY monetary ASC)       AS M_score
    FROM rfm_raw
)
SELECT
    *,
    (R_score + F_score + M_score)   AS rfm_total,
    CASE
        WHEN R_score >= 4 AND F_score >= 4 AND M_score >= 4 THEN 'Champions'
        WHEN R_score >= 3 AND F_score >= 3 AND M_score >= 3 THEN 'Loyal Customers'
        WHEN R_score >= 4 AND F_score <= 2                  THEN 'Recent Customers'
        WHEN R_score >= 3 AND F_score <= 2 AND M_score >= 3 THEN 'Potential Loyalists'
        WHEN R_score <= 2 AND F_score >= 3 AND M_score >= 3 THEN 'At Risk'
        WHEN R_score <= 2 AND F_score >= 4 AND M_score >= 4 THEN 'Cannot Lose Them'
        WHEN R_score <= 2 AND F_score <= 2 AND M_score <= 2 THEN 'Lost'
        ELSE 'Hibernating'
    END                             AS segment
FROM rfm_scored
ORDER BY rfm_total DESC;


-- 2.3 Segment Revenue Contribution Summary
WITH rfm_segments AS (
    -- (paste rfm_scored CTE from 2.2 here)
    SELECT
        CustomerID,
        CASE
            WHEN R_score >= 4 AND F_score >= 4 AND M_score >= 4 THEN 'Champions'
            WHEN R_score >= 3 AND F_score >= 3 AND M_score >= 3 THEN 'Loyal Customers'
            WHEN R_score >= 4 AND F_score <= 2                  THEN 'Recent Customers'
            WHEN R_score >= 3 AND F_score <= 2 AND M_score >= 3 THEN 'Potential Loyalists'
            WHEN R_score <= 2 AND F_score >= 3 AND M_score >= 3 THEN 'At Risk'
            WHEN R_score <= 2 AND F_score >= 4 AND M_score >= 4 THEN 'Cannot Lose Them'
            WHEN R_score <= 2 AND F_score <= 2 AND M_score <= 2 THEN 'Lost'
            ELSE 'Hibernating'
        END AS segment,
        monetary
    FROM (
        SELECT
            CustomerID, monetary,
            NTILE(5) OVER (ORDER BY recency_days DESC) AS R_score,
            NTILE(5) OVER (ORDER BY frequency ASC)     AS F_score,
            NTILE(5) OVER (ORDER BY monetary ASC)      AS M_score
        FROM (
            SELECT CustomerID,
                   COUNT(DISTINCT InvoiceNo)  AS frequency,
                   SUM(TotalPrice)            AS monetary,
                   DATEDIFF(DATE('2011-12-10'), MAX(InvoiceDate)) AS recency_days
            FROM transactions
            WHERE Quantity > 0 AND UnitPrice > 0
              AND InvoiceNo NOT LIKE 'C%'
            GROUP BY CustomerID
        ) base
    ) scored
)
SELECT
    segment,
    COUNT(*)                                    AS customer_count,
    ROUND(SUM(monetary), 2)                     AS total_revenue,
    ROUND(AVG(monetary), 2)                     AS avg_clv,
    ROUND(SUM(monetary) * 100.0 /
          SUM(SUM(monetary)) OVER (), 2)        AS revenue_pct
FROM rfm_segments
GROUP BY segment
ORDER BY total_revenue DESC;


-- =============================================================================
-- SECTION 3: COHORT ANALYSIS
-- =============================================================================

-- 3.1 Monthly Cohort Retention (First Purchase Month as Cohort)
WITH first_purchase AS (
    SELECT
        CustomerID,
        DATE_FORMAT(MIN(InvoiceDate), '%Y-%m')  AS cohort_month
    FROM transactions
    WHERE Quantity > 0 AND UnitPrice > 0
      AND InvoiceNo NOT LIKE 'C%'
    GROUP BY CustomerID
),
customer_activity AS (
    SELECT
        t.CustomerID,
        fp.cohort_month,
        DATE_FORMAT(t.InvoiceDate, '%Y-%m')     AS activity_month,
        PERIOD_DIFF(
            DATE_FORMAT(t.InvoiceDate, '%Y%m'),
            DATE_FORMAT(STR_TO_DATE(CONCAT(fp.cohort_month, '-01'), '%Y-%m-%d'), '%Y%m')
        )                                       AS month_number
    FROM transactions t
    JOIN first_purchase fp ON t.CustomerID = fp.CustomerID
    WHERE t.Quantity > 0 AND t.InvoiceNo NOT LIKE 'C%'
),
cohort_size AS (
    SELECT cohort_month, COUNT(DISTINCT CustomerID) AS cohort_customers
    FROM first_purchase
    GROUP BY cohort_month
)
SELECT
    ca.cohort_month,
    cs.cohort_customers,
    ca.month_number,
    COUNT(DISTINCT ca.CustomerID)               AS retained_customers,
    ROUND(COUNT(DISTINCT ca.CustomerID) * 100.0 / cs.cohort_customers, 1) AS retention_rate
FROM customer_activity ca
JOIN cohort_size cs ON ca.cohort_month = cs.cohort_month
WHERE ca.month_number BETWEEN 0 AND 11
GROUP BY ca.cohort_month, cs.cohort_customers, ca.month_number
ORDER BY ca.cohort_month, ca.month_number;


-- 3.2 Customer Purchase Frequency Distribution
SELECT
    frequency_bucket,
    COUNT(*)                                    AS customer_count,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 1) AS pct_customers,
    ROUND(AVG(monetary), 2)                     AS avg_spend
FROM (
    SELECT
        CustomerID,
        SUM(TotalPrice)     AS monetary,
        CASE
            WHEN COUNT(DISTINCT InvoiceNo) = 1  THEN '1 order (one-time)'
            WHEN COUNT(DISTINCT InvoiceNo) <= 3 THEN '2-3 orders'
            WHEN COUNT(DISTINCT InvoiceNo) <= 6 THEN '4-6 orders'
            WHEN COUNT(DISTINCT InvoiceNo) <= 10 THEN '7-10 orders'
            ELSE '10+ orders (loyal)'
        END AS frequency_bucket
    FROM transactions
    WHERE Quantity > 0 AND UnitPrice > 0
      AND InvoiceNo NOT LIKE 'C%'
    GROUP BY CustomerID
) freq_dist
GROUP BY frequency_bucket
ORDER BY MIN(
    CASE frequency_bucket
        WHEN '1 order (one-time)'   THEN 1
        WHEN '2-3 orders'           THEN 2
        WHEN '4-6 orders'           THEN 3
        WHEN '7-10 orders'          THEN 4
        ELSE 5
    END
);


-- =============================================================================
-- SECTION 4: A/B TEST SUPPORTING QUERIES
-- =============================================================================

-- 4.1 Baseline AOV before A/B test (for test design)
SELECT
    ROUND(AVG(invoice_total), 2)    AS mean_aov,
    ROUND(STDDEV(invoice_total), 2) AS std_aov,
    MIN(invoice_total)              AS min_aov,
    MAX(invoice_total)              AS max_aov,
    COUNT(*)                        AS n_orders
FROM (
    SELECT InvoiceNo, SUM(TotalPrice) AS invoice_total
    FROM transactions
    WHERE Quantity > 0 AND UnitPrice > 0
      AND InvoiceNo NOT LIKE 'C%'
    GROUP BY InvoiceNo
) invoice_totals;


-- 4.2 Segment-level AOV (use for test stratification)
WITH invoice_level AS (
    SELECT
        CustomerID,
        InvoiceNo,
        SUM(TotalPrice) AS invoice_total
    FROM transactions
    WHERE Quantity > 0 AND UnitPrice > 0
      AND InvoiceNo NOT LIKE 'C%'
    GROUP BY CustomerID, InvoiceNo
)
SELECT
    CASE
        WHEN avg_monetary >= 500 THEN 'High Value'
        WHEN avg_monetary >= 100 THEN 'Mid Value'
        ELSE 'Low Value'
    END                             AS value_tier,
    COUNT(DISTINCT CustomerID)      AS customers,
    ROUND(AVG(avg_monetary), 2)     AS avg_customer_spend,
    ROUND(AVG(avg_invoice), 2)      AS avg_order_value
FROM (
    SELECT CustomerID,
           AVG(invoice_total) AS avg_invoice,
           SUM(invoice_total) AS avg_monetary
    FROM invoice_level
    GROUP BY CustomerID
) customer_aov
GROUP BY value_tier
ORDER BY avg_customer_spend DESC;
