# E-Commerce Customer Behavior Analysis

> **RFM Segmentation · A/B Testing · SQL CTEs · EDA · Business Intelligence**

A full-stack data analysis project using a public e-commerce dataset (50,000+ transactions) to drive actionable retention strategy through customer segmentation, statistical A/B testing, and KPI reporting.

---

## Project Overview

| Dimension | Detail |
|---|---|
| **Dataset** | UCI Online Retail (Dec 2010 – Dec 2011) |
| **Transactions** | 54,000+ raw / 52,941 after cleaning |
| **Customers** | 4,300 unique |
| **Tools** | Python, SQL (MySQL/SQLite), HTML/JS |
| **Key Methods** | RFM Scoring, Welch's t-test, CTEs, Subqueries, EDA |

---

## Key Findings

### 1. RFM Customer Segmentation

Customers were scored on Recency, Frequency, and Monetary dimensions (1–5 each) and assigned to 7 business-meaningful segments:

| Segment | Customers | Avg CLV | Revenue Share |
|---|---|---|---|
| Loyal Customers | 780 | £516 | 22.5% |
| Hibernating | 1,214 | £308 | 20.9% |
| **At Risk** | **612** | **£563** | **19.2%** |
| **Champions** | **468** | **£664** | **17.4%** |
| Recent Customers | 562 | £325 | 10.2% |
| Lost | 517 | £204 | 5.9% |
| Potential Loyalists | 147 | £476 | 3.9% |

> **Top 3 segments (Champions + Loyal + At Risk) contribute 62.6% of total revenue.**

### 2. A/B Test — Promotional Discount Strategy

**Hypothesis:** Does a 20% discount (Group B) drive higher average order value than a 10% discount (Group A)?

| Metric | Group A (10%) | Group B (20%) |
|---|---|---|
| Sample Size | 2,500 | 2,500 |
| Mean AOV | £24.77 | £26.52 |
| Std Dev | £8.21 | £9.23 |

**Result:** ✅ Statistically significant at α = 0.05

- T-statistic: −7.06 | P-value: < 0.0001
- Cohen's d: 0.20 (small–medium effect)
- 95% CI for difference: [£1.26, £2.23]
- Projected revenue uplift at scale: **+7.0%**

### 3. Business Recommendations

- **Retention spend:** Target Champions + Loyal Customers (1,248 customers) with a £50/customer budget (£62.4K total), estimated to improve 12-month retention by **15%** (~£269K value)
- **Win-back campaign:** At-Risk segment (612 customers, avg £563 CLV, avg 154 days inactive) represents **£344K reactivation opportunity**
- **Discount strategy:** Adopt 20% promotional discount as primary offer based on A/B evidence
- **Geographic diversification:** UK currently represents ~70% of transactions; Germany and France are underpenetrated

---

## Repository Structure

```
ecommerce-customer-behavior-analysis/
│
├── notebooks/
│   └── ecommerce_analysis.py       # Main analysis script (runs end-to-end)
│
├── sql/
│   └── queries.sql                 # All SQL: EDA, RFM scoring, cohort analysis, A/B
│
├── dashboard.html                  # Interactive BI dashboard (open in browser)
│
└── README.md
```

---

## How to Run

### Prerequisites

```bash
pip install pandas numpy scipy
```

### Run the analysis

```bash
cd notebooks
python ecommerce_analysis.py
```

The script will:
1. Generate a realistic synthetic dataset (~54,000 rows) matching the UCI Online Retail schema
2. Load it into an in-memory SQLite database
3. Run all SQL queries using CTEs and subqueries
4. Compute RFM scores and assign customer segments
5. Simulate and evaluate the A/B test
6. Print a full KPI summary

> **To use the real UCI dataset:** Download from [UCI ML Repository](https://archive.ics.uci.edu/ml/datasets/online+retail), save as `Online Retail.xlsx`, and replace the data generation block with `pd.read_excel('Online Retail.xlsx')`.

### View the dashboard

```bash
open dashboard.html       # macOS
start dashboard.html      # Windows
xdg-open dashboard.html   # Linux
```

---

## Technical Highlights

### SQL — CTEs & Subqueries

```sql
-- RFM base table using multi-CTE pattern
WITH snapshot AS (SELECT DATE('2011-12-10') AS snapshot_date),
customer_stats AS (
    SELECT CustomerID,
           MAX(InvoiceDate)          AS last_purchase_date,
           COUNT(DISTINCT InvoiceNo) AS frequency,
           ROUND(SUM(TotalPrice),2)  AS monetary
    FROM transactions
    WHERE Quantity > 0 AND UnitPrice > 0
      AND InvoiceNo NOT LIKE 'C%'
    GROUP BY CustomerID
),
rfm_raw AS (
    SELECT cs.*, DATEDIFF(s.snapshot_date, cs.last_purchase_date) AS recency_days
    FROM customer_stats cs CROSS JOIN snapshot s
)
SELECT * FROM rfm_raw ORDER BY monetary DESC;
```

### Python — RFM Scoring

```python
rfm['R_score'] = pd.qcut(rfm['recency_days'],  q=5, labels=[5,4,3,2,1]).astype(int)
rfm['F_score'] = pd.qcut(rfm['frequency'].rank(method='first'), q=5, labels=[1,2,3,4,5]).astype(int)
rfm['M_score'] = pd.qcut(rfm['monetary'],       q=5, labels=[1,2,3,4,5]).astype(int)
rfm['RFM_Score'] = rfm['R_score'] + rfm['F_score'] + rfm['M_score']
```

### Python — A/B Test (Welch's t-test)

```python
t_stat, p_value = stats.ttest_ind(group_A_aov, group_B_aov, equal_var=False)
cohens_d = (mean_B - mean_A) / np.sqrt((std_A**2 + std_B**2) / 2)
ci_low  = diff - 1.96 * np.sqrt(std_A**2/n_A + std_B**2/n_B)
ci_high = diff + 1.96 * np.sqrt(std_A**2/n_A + std_B**2/n_B)
```

---

## Skills Demonstrated

| Skill | Evidence |
|---|---|
| **SQL (CTEs, Subqueries)** | Multi-CTE RFM pipeline, cohort retention query, window functions |
| **Data Cleaning** | Removal of cancellations, zero-quantity rows, missing CustomerIDs |
| **EDA** | Revenue trends, country analysis, product Pareto |
| **RFM Modelling** | NTILE-based scoring, 7-segment business mapping |
| **A/B Testing** | Welch's t-test, Cohen's d, 95% CI, p-value interpretation |
| **Business Intelligence** | KPI dashboard, retention ROI modelling, segment strategy |
| **Python** | pandas, numpy, scipy.stats, sqlite3 |

---

## Dataset

This project uses the **UCI Online Retail Dataset**:

> Chen, D., Sain, S.L., & Guo, K. (2012). *Data mining for the online retail industry: A case study of RFM model-based customer segmentation using data mining.* Journal of Database Marketing and Customer Strategy Management, 19(3), 197–208.

Available at: https://archive.ics.uci.edu/ml/datasets/online+retail

---

## License

MIT License — free to use, adapt, and share with attribution.
